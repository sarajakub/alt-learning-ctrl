/**
 * ArduinoController Class
 * Handles serial communication with Arduino to control the moon phase simulation
 * Supports rotary encoder input for Moon and Earth rotation
 */
class ArduinoController {
    constructor(simulation) {
        this._simulation = simulation;
        this._port = null;
        this._reader = null;
        this._writer = null;
        
        // Control state
        this._controllingEarth = false;
        this._isDragging = false;
        this._lastAngle = 0;
        this._rotationSensitivity = 0.1; // Adjust this to control rotation speed
        
        // Bind methods
        this.connect = this.connect.bind(this);
        this._handleSerialData = this._handleSerialData.bind(this);
    }

    /**
     * Connects to Arduino through Web Serial API
     */
    async connect() {
        try {
            // Request serial port access
            this._port = await navigator.serial.requestPort();
            await this._port.open({ baudRate: 9600 });

            // Set up serial reader
            const textDecoder = new TextDecoderStream();
            this._port.readable.pipeTo(textDecoder.writable);
            this._reader = textDecoder.readable.getReader();

            // Start reading loop
            this._readLoop();

            console.log('Successfully connected to Arduino');
        } catch (error) {
            console.error('Failed to connect to Arduino:', error);
        }
    }

    /**
     * Continuous loop to read serial data
     */
    async _readLoop() {
        try {
            while (true) {
                const { value, done } = await this._reader.read();
                if (done) {
                    break;
                }
    
                console.log("RAW serial value:", JSON.stringify(value)); // ✅ only in _readLoop
                this._handleSerialData(value.replace(/\r?\n|\r/g, '').trim());
            }
        } catch (error) {
            console.error('Error reading from Arduino:', error);
        }
    }

    /**
     * Handles incoming serial data and maps it to simulation controls
     * Commands:
     * - "M+/M-": Rotate Moon clockwise/counterclockwise
     * - "E+/E-": Rotate Earth clockwise/counterclockwise
     * - "CM": Switch to Moon control
     * - "CE": Switch to Earth control
     * - "P": Toggle play/pause
     * - "R": Reset to initial state
     * - "Sxxx": Set simulation speed (xxx is value between 020 and 999)
     */
    _handleSerialData(command) {
        console.log("Parsed command:", JSON.stringify(command)); // Shows newline/carriage returns
        console.log('Received command:', command);
        console.log("Dragging target:", this._simulation._orbitDiagram);
        console.log(window.WGBH.lunarPhasesAsset3);

        switch(command[0]) {
            case 'M': // Moon rotation
                if (!this._isDragging) {
                    this._startDragging(false); // Start dragging Moon
                }
                this._handleRotation(command[1] === '+' ? 1 : -1);
                break;
                
            case 'E': // Earth rotation
                if (!this._isDragging) {
                    this._startDragging(true); // Start dragging Earth
                }
                this._handleRotation(command[1] === '+' ? 1 : -1);
                break;
                
            case 'C': // Control mode change
            this._controllingEarth = command[1] === 'E';
            if (this._isDragging) {
                this._stopDragging();
            }
            this._updateControlModeUI();
            break;
            
            case 'P': // Play/Pause toggle
                if (this._simulation._timekeeper.getIsPlaying()) {
                    this._simulation.pause();
                } else {
                    this._simulation.play();
                }
                break;
                
            case 'R': // Reset
                this._simulation._timekeeper.setTime({ calendarDay: 1, fractionalTimeOfDay: 0.5 });
                break;
                
            case 'S': // Speed control
                const speed = parseInt(command.substring(1));
                if (!isNaN(speed) && speed >= 20 && speed <= 999) {
                    this._simulation._timekeeper.setSecondsPerCalendarPeriod(speed);
                }
                break;
        }
    }

    /**
     * Starts dragging the selected element (Moon or Earth)
     */
    _startDragging(isEarth) {
        this._isDragging = true;
        this._controllingEarth = isEarth;
        this._lastAngle = 0;
        
        // Simulate starting drag on the appropriate element
        const element = isEarth ? this._simulation._orbitDiagram._earth : this._simulation._orbitDiagram._moon;
        element._startDragging({ x: 0, y: 0 }, element.TYPE_MOUSE);
    }

    /**
     * Handles rotation from encoder input
     */
    _handleRotation(direction) {
        if (!this._isDragging) return;
        
        // Calculate new angle based on encoder direction
        const deltaAngle = direction * this._rotationSensitivity;
        this._lastAngle += deltaAngle;
        
        // Simulate mouse movement to achieve rotation
        const element = this._controllingEarth ? 
            this._simulation._orbitDiagram._earth : 
            this._simulation._orbitDiagram._moon;
            
        element._updateDragging({
            x: Math.cos(this._lastAngle),
            y: Math.sin(this._lastAngle)
        });
    }

    /**
     * Stops dragging the current element
     */
    _stopDragging() {
        if (!this._isDragging) return;
        
        const element = this._controllingEarth ? 
            this._simulation._orbitDiagram._earth : 
            this._simulation._orbitDiagram._moon;
            
        element._stopDragging();
        this._isDragging = false;
    }

    /**
     * Disconnects from the Arduino
     */
    async disconnect() {
        if (this._isDragging) {
            this._stopDragging();
        }
        
        if (this._reader) {
            await this._reader.cancel();
            this._reader = null;
        }
        
        if (this._port) {
            await this._port.close();
            this._port = null;
        }
    }
    /**
     * Updates the on-screen UI to show current control mode
     */
    _updateControlModeUI() {
        const display = document.getElementById('controlModeDisplay');
        if (display) {
            display.textContent = 'Controlling: ' + (this._controllingEarth ? 'Earth' : 'Moon');
        }
    }
}

// Export the controller
window.WGBH = window.WGBH || {};
window.WGBH.ArduinoController = ArduinoController; 